from django.urls import path
from .views import StudentListView, StudentDetailView, CourseListView, home_view

urlpatterns = [
    path('', home_view, name='home'),
    path('students/', StudentListView.as_view(), name='student_list'),
    path('students/<int:pk>/', StudentDetailView.as_view(), name='student_detail'),
    path('courses/', CourseListView.as_view(), name='course_list'),
]
