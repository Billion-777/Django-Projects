from django.contrib import admin
from .models import Student, Course

class CourseInline(admin.TabularInline):
    model = Student.courses.through
    extra = 1

@admin.register(Student)
class StudentAdmin(admin.ModelAdmin):
    list_display = ('USN', 'name', 'gender', 'semester')
    search_fields = ('USN', 'name')
    inlines = [CourseInline]
    exclude = ('courses',)  # To prevent the M2M field from showing up twice

@admin.register(Course)
class CourseAdmin(admin.ModelAdmin):
    list_display = ('course_no', 'course_name', 'duration', 'fees')
    search_fields = ('course_no', 'course_name')
    inlines = [CourseInline]
