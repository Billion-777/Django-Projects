from django.apps import AppConfig


class FeedReaderConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'feed_reader'
