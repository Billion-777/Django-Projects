from django.apps import AppConfig


class TextfilereaderappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'TextfileReaderApp'
