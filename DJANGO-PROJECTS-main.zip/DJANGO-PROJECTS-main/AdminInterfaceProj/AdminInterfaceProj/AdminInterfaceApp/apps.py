from django.apps import AppConfig


class AdmininterfaceappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'AdminInterfaceApp'
