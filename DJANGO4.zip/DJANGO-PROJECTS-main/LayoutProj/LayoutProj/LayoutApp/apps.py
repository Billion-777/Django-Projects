from django.apps import AppConfig


class LayoutappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'LayoutApp'
